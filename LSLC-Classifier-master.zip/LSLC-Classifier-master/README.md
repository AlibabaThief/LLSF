# LSLC-Classifier
Lease square error linear classifier
